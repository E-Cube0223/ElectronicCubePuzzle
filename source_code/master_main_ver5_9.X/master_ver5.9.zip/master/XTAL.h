
#ifndef _XTAL_H
#define	_XTAL_H
#define _XTAL_FREQ 64000000 //__delay�p
#endif	

